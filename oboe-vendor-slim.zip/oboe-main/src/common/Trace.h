/*
 * Copyright 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef OBOE_TRACE_H
#define OBOE_TRACE_H

#include <cstdint>

namespace oboe {

/**
 * Wrapper for tracing use with Perfetto
 */
class Trace {

public:
    static Trace &getInstance() {
        static Trace instance;
        return instance;
    }

    /**
     * @return true if Perfetto tracing is enabled.
     */
    bool isEnabled() const;

    /**
     * Only call this function if isEnabled() returns true.
     * @param format
     * @param ...
     */
    void beginSection(const char *format, ...);

    /**
     * Only call this function if isEnabled() returns true.
     */
    void endSection() const;

    /**
     * Only call this function if isEnabled() returns true.
     * @param counterName human readable name
     * @param counterValue value to log in trace
     */
    void setCounter(const char *counterName, int64_t counterValue) const;

private:
    Trace();
// Tracing functions
    void *(*ATrace_beginSection)(const char *sectionName) = nullptr;

    void *(*ATrace_endSection)() = nullptr;

    void *(*ATrace_setCounter)(const char *counterName, int64_t counterValue) = nullptr;

    bool *(*ATrace_isEnabled)(void) = nullptr;
};

}
#endif //OBOE_TRACE_H
