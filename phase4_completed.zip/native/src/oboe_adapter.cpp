#include "oboe_adapter.h"
#include <android/log.h>
#include <string.h>

#define TAG "oboe_adapter"
#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

#ifdef USE_OBOE
// Real Oboe-mode implementation (will compile only if Oboe is provided)
#include <oboe/AudioStreamBuilder.h>
#include <oboe/AudioStreamCallback.h>
#include <oboe/Definitions.h>
#include <memory>
using namespace oboe;

class Callback : public AudioStreamCallback {
public:
    Callback() {}
    DataCallbackResult onAudioReady(AudioStream* oboeStream, void* audioData, int32_t numFrames) override {
        // Simple passthrough / silence for now
        memset(audioData, 0, numFrames * oboeStream->getChannelCount() * sizeof(float));
        return DataCallbackResult::Continue;
    }
};

static std::unique_ptr<AudioStream> sStream;
static Callback sCallback;

bool oboe_adapter_start(int sampleRate, int channels) {
    AudioStreamBuilder builder;
    builder.setPerformanceMode(PerformanceMode::LowLatency)
           .setSharingMode(SharingMode::Exclusive)
           .setFormat(AudioFormat::Float)
           .setChannelCount(channels)
           .setSampleRate(sampleRate)
           .setCallback(&sCallback);
    Result r = builder.openStream(sStream);
    if (r != Result::OK || !sStream) {
        ALOGI("Failed to open oboe stream: %d", (int)r);
        return false;
    }
    sStream->requestStart();
    ALOGI("Oboe stream started sr=%d ch=%d", sampleRate, channels);
    return true;
}

bool oboe_adapter_stop() {
    if (sStream) {
        sStream->requestStop();
        sStream->close();
        sStream.reset();
        ALOGI("Oboe stopped");
        return true;
    }
    return false;
}

void oboe_adapter_apply_state(const char* jsonState) {
    ALOGI("oboe_adapter_apply_state len=%d", (int)strlen(jsonState));
}

void oboe_adapter_get_meters(float* outPeaks, int count) {
    for (int i = 0; i < count; ++i) outPeaks[i] = 0.0f;
}

#else
// Fallback mode: simple mock audio engine using a background thread to simulate processing
#include <thread>
#include <atomic>
#include <vector>
#include <chrono>
#include <mutex>

static std::atomic<bool> s_running(false);
static std::thread s_thread;
static std::mutex s_mutex;
static int s_sampleRate = 48000;
static int s_channels = 2;
static std::vector<float> s_meters;

static void processing_loop() {
    using namespace std::chrono;
    const int period_ms = 10; // simulate 10ms buffer period
    while (s_running.load()) {
        {
            std::lock_guard<std::mutex> lk(s_mutex);
            // simulate meter changes
            for (int i = 0; i < s_channels; ++i) {
                s_meters[i] = (float)(rand() % 100) / 100.0f;
            }
        }
        std::this_thread::sleep_for(milliseconds(period_ms));
    }
}

bool oboe_adapter_start(int sampleRate, int channels) {
    std::lock_guard<std::mutex> lk(s_mutex);
    if (s_running.load()) return false;
    s_sampleRate = sampleRate;
    s_channels = channels;
    s_meters.assign(channels, 0.0f);
    s_running.store(true);
    s_thread = std::thread(processing_loop);
    ALOGI("oboe_adapter (fallback) started sr=%d ch=%d", sampleRate, channels);
    return true;
}

bool oboe_adapter_stop() {
    {
        std::lock_guard<std::mutex> lk(s_mutex);
        if (!s_running.load()) return false;
        s_running.store(false);
    }
    if (s_thread.joinable()) s_thread.join();
    ALOGI("oboe_adapter (fallback) stopped");
    return true;
}

void oboe_adapter_apply_state(const char* jsonState) {
    std::lock_guard<std::mutex> lk(s_mutex);
    ALOGI("oboe_adapter_apply_state (fallback) len=%d", (int)strlen(jsonState));
}

void oboe_adapter_get_meters(float* outPeaks, int count) {
    std::lock_guard<std::mutex> lk(s_mutex);
    for (int i = 0; i < count && i < (int)s_meters.size(); ++i) outPeaks[i] = s_meters[i];
    for (int i = (int)s_meters.size(); i < count; ++i) outPeaks[i] = 0.0f;
}

#endif
