#include "oboe_adapter.h"
#include "dsp_api.h"
// simple wrappers to connect oboe_adapter to dsp_api
bool oboe_adapter_start(int sampleRate, int channels);
bool oboe_adapter_stop();
void oboe_adapter_apply_state(const char* jsonState);
void oboe_adapter_get_meters(float* outPeaks, int count);

bool dsp_start(int sampleRate, int channels) { return oboe_adapter_start(sampleRate, channels); }
bool dsp_stop() { return oboe_adapter_stop(); }
void dsp_apply_state_json(const char* jsonState) { oboe_adapter_apply_state(jsonState); }
void dsp_get_meters(float* outPeaks) { oboe_adapter_get_meters(outPeaks, 8); }
