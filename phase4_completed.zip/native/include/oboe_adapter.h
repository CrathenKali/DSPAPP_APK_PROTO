#ifndef OBOE_ADAPTER_H
#define OBOE_ADAPTER_H
#ifdef __cplusplus
extern "C" {
#endif
bool oboe_adapter_start(int sampleRate, int channels);
bool oboe_adapter_stop();
void oboe_adapter_apply_state(const char* jsonState);
void oboe_adapter_get_meters(float* outPeaks, int count);
#ifdef __cplusplus
}
#endif
#endif
