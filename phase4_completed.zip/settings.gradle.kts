rootProject.name = "DSPAppPhase4_Completed"
include(":app")
include(":native")
