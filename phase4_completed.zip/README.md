DSPAppPhase4 - Completed assembly (with Oboe integration scaffold)

What you get:
- app/ module with JNI bridge
- native/ module scaffolding for Oboe (optionally build)
- oboe_adapter with two modes:
  * REAL Oboe mode (requires Oboe sources/prebuilt and -DUSE_OBOE=ON)
  * FALLBACK MOCK mode (buildable & runnable without Oboe; simulates audio callback)
- Validation scripts including a mock latency test that runs in the fallback mode.

To enable real Oboe:
1. Add Oboe as a submodule at native/oboe or provide a prebuilt liboboe.
2. Configure CMake to -DUSE_OBOE=ON and point to Oboe include/lib.
3. Build with Android Studio/NDK.

This package is ready to unzip and open in Android Studio. If you want, I can also attempt to fetch Oboe sources and vendor them into the package (requires network access).
