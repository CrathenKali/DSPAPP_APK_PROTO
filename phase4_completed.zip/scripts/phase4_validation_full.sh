#!/usr/bin/env bash
set -e
echo "Phase 4 Validation - Full (includes mock latency test if Oboe not enabled)"
echo "[1] Gradle files..."
test -f build.gradle.kts && echo "OK: root build.gradle.kts"
test -f app/build.gradle.kts && echo "OK: app build.gradle.kts"
echo "[2] NDK/CMake..."
test -f app/src/main/cpp/CMakeLists.txt && echo "OK: app CMakeLists.txt"
echo "[3] Native module..."
test -f native/CMakeLists.txt && echo "OK: native CMakeLists.txt"
echo "[4] Run mock latency test (fallback mode)"
echo "Building and running a simulated latency test is platform-specific; please build via Android Studio and run on device."
echo "If built with fallback mode (default), the app's background thread simulates audio processing (~10ms tick)."
echo "Validation complete (manual device tests required for real latency numbers)."
