plugins { `kotlin-dsl` }
buildscript {
    repositories { google(); mavenCentral(); maven("https://jitpack.io") }
    dependencies {
        classpath("com.android.tools.build:gradle:7.4.2")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.8.21")
    }
}
allprojects { repositories { google(); mavenCentral(); maven("https://jitpack.io") } }
